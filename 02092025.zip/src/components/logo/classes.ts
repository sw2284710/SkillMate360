import { createClasses } from 'src/theme/create-classes';

// ----------------------------------------------------------------------

export const logoClasses = {
  root: createClasses('logo__root'),
};
