import { createClasses } from 'src/theme/create-classes';

// ----------------------------------------------------------------------

export const labelClasses = {
  root: createClasses('label__root'),
  icon: createClasses('label__icon'),
};
