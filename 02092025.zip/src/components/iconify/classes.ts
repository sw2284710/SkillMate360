import { createClasses } from 'src/theme/create-classes';

// ----------------------------------------------------------------------

export const iconifyClasses = {
  root: createClasses('iconify__root'),
};
