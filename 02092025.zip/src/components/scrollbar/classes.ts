import { createClasses } from 'src/theme/create-classes';

// ----------------------------------------------------------------------

export const scrollbarClasses = {
  root: createClasses('scrollbar__root'),
};
